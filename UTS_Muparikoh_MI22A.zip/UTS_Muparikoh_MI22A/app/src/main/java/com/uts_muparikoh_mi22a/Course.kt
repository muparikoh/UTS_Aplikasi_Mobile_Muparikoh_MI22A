package com.uts_muparikoh_mi22a

data class Course(

    val title: String,
    val path: String,
    val image: String
)
